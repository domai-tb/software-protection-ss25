This file was provided by https://iosninja.io

****** DISCLAIMER AND LIMITATION OF LIABILITY ******

All "dll" and "zip" files downloaded from this website (https://iosninja.io) are free of charge and are provided on an as is basis.

By using/installing this file, the user assumes all risks of any damages that may occur including but not limited to loss of data, damages to hardware, or loss of business profits. Please use these files at your own risk. iOS Ninja (https://iosninja.io) and its team will not be held responsible for any damages that may arise from the use of DLL files.